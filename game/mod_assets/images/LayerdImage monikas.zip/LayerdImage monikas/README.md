# Non-Sientient monika sprites
# sprite artis - @iansuller_blogger
# LayerdImage code - @NekoLaiS


# Everything inside the folder should be moved to the "yourmod/game/" folder.
# Since the code uses a module from python 3, it is recommended to use on ren'py 8.0.0 or higher 